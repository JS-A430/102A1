﻿using Circuits;
using System.Drawing;
using Circuits.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class AndGate : Gate
{
    public AndGate(int x, int y) : base(x, y)
    {
        // Load images
        imgNormal = Circuits.Properties.Resources.AndGate;
        imgSelected = Circuits.Properties.Resources.AndGateAllRed; // separate image for selection

        Pins.Add(new Pin(this, false, 0, 10));
        Pins.Add(new Pin(this, false, 0, 40));
        Pins.Add(new Pin(this, true, 50, 25));
    }

    public override bool Evaluate()
    {
        bool result = true;
        foreach (var pin in Pins)
        {
            if (!pin.IsOutput)
                result &= pin.InputWire?.Value ?? false;
        }

        Pins.Find(p => p.IsOutput).Value = result;
        return result;
    }

    public override void Draw(Graphics g)
    {
        // Draw selected or normal image
        g.DrawImage(Selected ? imgSelected : imgNormal, Left, Top, 50, 50);

        // Draw pins
        foreach (var p in Pins)
            p.Draw(g);
    }

    public override Gate Clone()
    {
        var copy = new AndGate(Left, Top);

        // Clone each pin
        copy.Pins.Clear();
        foreach (var pin in Pins)
        {
            copy.Pins.Add(new Pin(copy, pin.IsOutput, pin.OffsetX, pin.OffsetY));
        }

        return copy;
    }
}
