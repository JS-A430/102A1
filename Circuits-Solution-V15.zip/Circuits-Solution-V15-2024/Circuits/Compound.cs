﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace Circuits
{
    public class Compound : Gate
    {
        // List of gates inside the compound
        public List<Gate> Gates { get; private set; } = new List<Gate>();

        public Compound(int x, int y) : base(x, y)
        {
        }

        /// <summary>
        /// Add a gate to the compound
        /// </summary>
        public void AddGate(Gate g)
        {
            Gates.Add(g);
        }

        /// <summary>
        /// Move the compound so all gates move together
        /// </summary>
        public override void MoveTo(int x, int y)
        {
            int dx = x - Left;
            int dy = y - Top;

            Left = x;
            Top = y;

            foreach (var g in Gates)
                g.MoveTo(g.Left + dx, g.Top + dy);
        }

        /// <summary>
        /// Evaluate all contained gates
        /// Returns OR of all outputs 
        /// </summary>
        public override bool Evaluate()
        {
            bool result = false;

            foreach (var g in Gates)
                result |= g.Evaluate();

            return result;
        }

        /// <summary>
        /// Draw all contained gates and selection rectangle if selected
        /// </summary>
        public override void Draw(Graphics g)
        {
            foreach (var gate in Gates)
                gate.Draw(g);

            if (Selected && Gates.Count > 0)
            {
                int left = int.MaxValue, top = int.MaxValue;
                int right = int.MinValue, bottom = int.MinValue;

                foreach (var gate in Gates)
                {
                    left = Math.Min(left, gate.Left);
                    top = Math.Min(top, gate.Top);
                    right = Math.Max(right, gate.Left + 50);
                    bottom = Math.Max(bottom, gate.Top + 50);
                }

                g.DrawRectangle(Pens.Blue, left - 2, top - 2, right - left + 4, bottom - top + 4);
            }
        }

        /// <summary>
        /// Returns true if the mouse is over any contained gate
        /// </summary>
        public override bool IsMouseOn(int mouseX, int mouseY)
        {
            foreach (var gate in Gates)
            {
                if (gate.IsMouseOn(mouseX, mouseY))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Clone the compound and all its gates
        /// </summary>
        public override Gate Clone()
        {
            var compoundCopy = new Compound(Left, Top);
            var gateMap = new Dictionary<Gate, Gate>();

            foreach (var g in Gates)
            {
                var clone = g.Clone();
                compoundCopy.AddGate(clone);
                gateMap[g] = clone;
            }


            return compoundCopy;
        }
    }
}
