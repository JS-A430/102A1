﻿using System.Drawing;

namespace Circuits
{
    public class OutputLamp : Gate
    {
        // Tracks whether the lamp is on or off
        public bool IsOn { get; private set; } = false;

        public OutputLamp(int x, int y) : base(x, y)
        {
            // One input pin on the left
            Pins.Add(new Pin(this, false, 0, 25));
        }

        /// <summary>
        /// Evaluate the input and update lamp state
        /// </summary>
        public override bool Evaluate()
        {
            var inputPin = Pins.Find(p => !p.IsOutput);
            bool inputValue = inputPin?.InputWire?.Value ?? false;

            // Lamp glows if input is true
            IsOn = inputValue;

            return IsOn;
        }

        public override void Draw(Graphics g)
        {
            Rectangle rect = new Rectangle(Left, Top, 50, 50);

            // Determine fill color
            Brush fillBrush;

            if (IsOn)
            {
                fillBrush = Brushes.Yellow; // fully on
            }
            else if (Selected)
            {
                fillBrush = Brushes.LightGoldenrodYellow; // faint glow when selected
            }
            else
            {
                fillBrush = Brushes.DarkGray; // off
            }

            // Draw lamp circle
            g.FillEllipse(fillBrush, rect);
            g.DrawEllipse(Pens.Black, rect);

            // Highlight selection (optional extra rectangle)
            if (Selected)
                g.DrawRectangle(Pens.Blue, Left - 2, Top - 2, 54, 54);

            // Draw pins
            foreach (var p in Pins)
                p.Draw(g);
        }

        public override Gate Clone()
        {
            var copy = new OutputLamp(Left, Top)
            {
                IsOn = this.IsOn
            };
            copy.Pins.Clear();
            foreach (var pin in Pins)
                copy.Pins.Add(new Pin(copy, pin.IsOutput, pin.OffsetX, pin.OffsetY));

            return copy;
        }
    }
}
