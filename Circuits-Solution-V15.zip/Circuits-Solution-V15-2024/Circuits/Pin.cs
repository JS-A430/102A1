﻿using System;
using System.Drawing;
using Circuits;


namespace Circuits
{
    public class Pin
    {
        public Gate Owner { get; }
        public bool IsOutput { get; }
        public int OffsetX { get; }
        public int OffsetY { get; }

        public bool IsInput => !IsOutput;


        public Wire InputWire { get; set; }   // if this pin is an input, wire connected to it

        // Boolean signal carried by this pin
        public bool Value { get; set; } = false;

        public int X { get; private set; }
        public int Y { get; private set; }

        public Pin(Gate owner, bool isOutput, int offsetX, int offsetY)
        {
            Owner = owner;
            IsOutput = isOutput;
            OffsetX = offsetX;
            OffsetY = offsetY;
            UpdatePosition();
        }

        public void UpdatePosition()
        {
            X = Owner.Left + OffsetX;
            Y = Owner.Top + OffsetY;
        }

        public void Draw(Graphics g)
        {
            g.FillEllipse(IsOutput ? Brushes.Blue : Brushes.Red, X - 3, Y - 3, 6, 6);
        }

        
        public bool IsMouseOn(int mouseX, int mouseY)
        {
            int dx = mouseX - X;
            int dy = mouseY - Y;
            return (dx * dx + dy * dy) <= 25; // circle radius 5
        }

        
    }
}
