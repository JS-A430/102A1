﻿using System.Collections.Generic;
using System.Drawing;

namespace Circuits
{
    /// <summary>
    /// Abstract base class for all types of gates
    /// Provides core properties and functionality common to all gates
    /// </summary>
    public abstract class Gate
    {
        /// <summary>
        /// The X coordinate (left position) of the gate on the canvas.
        /// </summary>
        public int Left { get; protected set; }

        /// <summary>
        /// The Y coordinate (top position) of the gate on the canvas.
        /// </summary>
        public int Top { get; protected set; }

        /// <summary>
        /// Whether this gate is currently selected
        /// </summary>
        public bool Selected { get; set; } = false;

        public List<Pin> Pins { get; protected set; } = new List<Pin>();

        protected Image imgNormal; // Image shown when the gate is drawn normally
        protected Image imgSelected; // Image shown when the gate is selected

        /// <summary>
        /// Constructor: creates a gate positioned at (x, y).
        /// </summary>
        public Gate(int x, int y)
        {
            Left = x;
            Top = y;
        }

        public virtual void MoveTo(int x, int y)
        {
            Left = x;
            Top = y;
            foreach (var p in Pins)
                p.UpdatePosition();
        }
        /// <summary>
        /// Returns true if the mouse is currently positioned over this gate
        /// Assumes each gate occupies a 50x50 pixel square
        /// </summary>
        public virtual bool IsMouseOn(int mouseX, int mouseY)
        {
            return mouseX >= Left && mouseX <= Left + 50 &&
                   mouseY >= Top && mouseY <= Top + 50;
        }
        /// <summary>
        /// Evaluate the gate’s output value
        /// </summary>
        public abstract bool Evaluate();

        public virtual void DrawImage(Graphics g)
        {
            if (imgNormal != null)
                g.DrawImage(Selected && imgSelected != null ? imgSelected : imgNormal, Left, Top, 50, 50);

            foreach (var pin in Pins)
                pin.Draw(g);
        }

        public abstract void Draw(Graphics g);

        /// <summary>
        /// Create a fresh copy of the gate, including cloned pins
        /// </summary>
        public abstract Gate Clone();
    }
}
