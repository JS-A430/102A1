﻿using System.Drawing;
using Circuits.Properties; // ensure this matches your project namespace

namespace Circuits
{
    public class OrGate : Gate
    {
        public OrGate(int x, int y) : base(x, y)
        {
            // Load normal and selected images from Resources
            imgNormal = Resources.OrGate;
            imgSelected = Resources.OrGateAllRed; // make sure this exists in Resources

            // Two inputs on the left
            Pins.Add(new Pin(this, false, 0, 10));
            Pins.Add(new Pin(this, false, 0, 40));

            // One output on the right
            Pins.Add(new Pin(this, true, 50, 25));
        }

        /// <summary>
        /// Evaluate the OR of all input pins
        /// </summary>
        public override bool Evaluate()
        {
            bool result = false;

            foreach (var pin in Pins)
            {
                if (!pin.IsOutput)
                    result |= pin.InputWire?.Value ?? false;
            }

            var outputPin = Pins.Find(p => p.IsOutput);
            if (outputPin != null)
                outputPin.Value = result;

            return result;
        }

        public override void Draw(Graphics g)
        {
            // Draw the correct image based on selection
            g.DrawImage(Selected && imgSelected != null ? imgSelected : imgNormal, Left, Top, 50, 50);

            // Draw pins
            foreach (var p in Pins)
                p.Draw(g);
        }
    

    public override Gate Clone()
        {
            var copy = new OrGate(Left, Top);

            // Clone each pin
            copy.Pins.Clear();
            foreach (var pin in Pins)
            {
                copy.Pins.Add(new Pin(copy, pin.IsOutput, pin.OffsetX, pin.OffsetY));
            }

            return copy;
        }
    }

}
