﻿using System.Drawing;

namespace Circuits
{
    public class Wire
    {
        public Pin Output { get; private set; }   // source pin
        public Pin Input { get; private set; }    // end pin

        public Wire(Pin output, Pin input)
        {
            Output = output;
            Input = input;
        }

        /// <summary>
        /// Value carried by the wire
        /// </summary>
        public bool Value => Output?.Value ?? false;

        public void Draw(Graphics g)
        {
            g.DrawLine(Pens.White, Output.X, Output.Y, Input.X, Input.Y);
        }
    }
}
