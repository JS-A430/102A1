﻿using System.Drawing;

namespace Circuits
{
    public class InputSource : Gate
    {
        public bool Value { get; private set; } = false;

        private const int SIZE = 50; // size of the gate square

        public InputSource(int x, int y) : base(x, y)
        {
            // One output pin on the right middle
            Pins.Add(new Pin(this, true, SIZE, SIZE / 2));
        }

        /// <summary>
        /// Toggle the boolean value when clicked.
        /// Updates output pin value as well.
        /// </summary>
        public void Toggle()
        {
            Value = !Value;
            Pins[0].Value = Value;
        }

        public override bool Evaluate()
        {
            // Always return the current value
            return Value;
        }

        public override void Draw(Graphics g)
        {
            // Update pin positions in case the gate moved
            foreach (var pin in Pins)
                pin.UpdatePosition();

            // Fill color depends on value
            Brush fillBrush = Value ? Brushes.LightGreen : Brushes.LightGray;
            g.FillRectangle(fillBrush, Left, Top, SIZE, SIZE);

            // Draw border
            g.DrawRectangle(Pens.Black, Left, Top, SIZE, SIZE);

            // Highlight if selected
            if (Selected)
                g.DrawRectangle(Pens.Blue, Left - 2, Top - 2, SIZE + 4, SIZE + 4);

            // Draw the value text inside the gate
            string text = Value ? "1" : "0";
            using (var font = new Font("Arial", 14))
            {
                var sf = new StringFormat()
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center
                };
                g.DrawString(text, font, Brushes.Black,
                    new RectangleF(Left, Top, SIZE, SIZE), sf);
            }

            // Draw pins
            foreach (var pin in Pins)
                pin.Draw(g);
        }

        public override Gate Clone()
        {
            var copy = new InputSource(Left, Top)
            {
                Value = this.Value
            };
            copy.Pins.Clear();
            foreach (var pin in Pins)
                copy.Pins.Add(new Pin(copy, pin.IsOutput, pin.OffsetX, pin.OffsetY));

            return copy;
        }
    }
}
