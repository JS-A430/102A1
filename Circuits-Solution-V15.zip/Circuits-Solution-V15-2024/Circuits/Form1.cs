﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Circuits
{

    /// <summary>
    /// Main form for the digital circuit editor.
    /// Handles drawing gates and wires, user input, and gate placement/manipulation.
    /// </summary>
    
    public partial class Form1 : Form
    {
        protected int startX = -1, startY = -1;
        protected int currentX = 0, currentY = 0;
        protected Pin startPin = null;

        protected List<Gate> gatesList = new List<Gate>();
        protected List<Wire> wiresList = new List<Wire>();

        protected Gate current = null;   // selected gate
        protected Gate newGate = null;   // gate being inserted
        protected Compound newCompound = null;  // compound being created

        /// <summary>
        /// Constructor: initializes form and enables double buffering for smooth drawing.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;  // smooth drawing
        }

        // Find a pin near the mouse
        public Pin findPin(int x, int y)
        {
            foreach (Gate g in gatesList)
            {
                foreach (Pin p in g.Pins)
                {
                    if (p.IsMouseOn(x, y))
                        return p;
                }
            }
            return null;
        }

        /// <summary>
        /// Handles mouse down events to start dragging a gate or connecting a wire.
        /// </summary>
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (newGate != null) return; // ignore selection while placing new gate

            startPin = findPin(e.X, e.Y);
            // If no pin clicked, check for gate selection
            if (startPin == null)
            {
                foreach (Gate g in gatesList)
                {
                    if (g.IsMouseOn(e.X, e.Y))
                    {
                        current = g;
                        current.Selected = true;
                        startX = e.X;
                        startY = e.Y;
                        currentX = current.Left;
                        currentY = current.Top;
                        Invalidate();
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Handles mouse move events to drag a wire or move a gate.
        /// </summary>
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (startPin != null)// Dragging a wire from startPin
            {
                currentX = e.X;
                currentY = e.Y;
                Invalidate();
            }
            else if (startX >= 0 && startY >= 0 && current != null) // Dragging a gate
            {
                current.MoveTo(currentX + (e.X - startX), currentY + (e.Y - startY));
                Invalidate();
            }
            else if (newGate != null) // Moving new gate before placing
            {
                currentX = e.X;
                currentY = e.Y;
                Invalidate();
            }
        }

        /// <summary>
        /// Handles mouse up events: finishes dragging or creates a wire if needed.
        /// </summary>
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (startPin != null)
            {
                Pin endPin = findPin(e.X, e.Y);
                if (endPin != null && startPin != endPin)
                {
                    Pin input, output;
                    if (startPin.IsOutput)
                    {
                        output = startPin;
                        input = endPin;
                    }
                    else
                    {
                        output = endPin;
                        input = startPin;
                    }

                    if (input.IsInput && output.IsOutput)
                    {
                        if (input.InputWire == null)
                        {
                            Wire newWire = new Wire(output, input);
                            input.InputWire = newWire;
                            wiresList.Add(newWire);
                        }
                        else
                        {
                            MessageBox.Show("That input is already used.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error: connect output to input only.");
                    }
                }
                startPin = null;
                Invalidate();
            }

            startX = -1;
            startY = -1;
            currentX = 0;
            currentY = 0;
        }

        /// <summary>
        /// Handles mouse clicks: places new gate, toggles InputSource, or adds gate to compound.
        /// </summary>
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (newGate != null)
            {
                newGate.MoveTo(e.X, e.Y);
                gatesList.Add(newGate);
                newGate = null;
                Invalidate();
                return;


            }
            
            if (newCompound != null && current != null) // Add currently selected gate to compound if grouping
            {
                AddSelectedToCompound();
            }

            if (current != null)// Deselect current gate
            {
                current.Selected = false;
                current = null;
                Invalidate();
            }

            foreach (Gate g in gatesList)// Select a gate under mouse
            {
                if (g.IsMouseOn(e.X, e.Y))
                {
                    current = g;
                    current.Selected = true;

                    // Toggle InputSource value on click
                    if (current is InputSource input)
                    {
                        input.Toggle();
                        Invalidate();  // redraw so color updates
                    }

                    Invalidate();
                    break;
                }
            }
        }

        /// <summary>
        /// Paint event: draws all gates, wires, and any wire or gate being dragged.
        /// </summary>
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            foreach (Wire w in wiresList)// Draw wires first so gates are on top
                w.Draw(g);

            
            foreach (Gate gate in gatesList) // Draw all gates
                gate.Draw(g);

            
            if (startPin != null)// Draw wire being dragged
                g.DrawLine(Pens.White, startPin.X, startPin.Y, currentX, currentY);

            
            if (newGate != null)// Draw new gate being dragged
            {
                newGate.MoveTo(currentX, currentY);
                newGate.Draw(g);
            }
        }

        /// <summary>
        /// Toolbar buttons to create gates
        /// </summary>
       
        private void toolStripButtonAnd_Click(object sender, EventArgs e)
        {
            newGate = new AndGate(0, 0);
        }

        private void toolStripButtonInputSource_Click(object sender, EventArgs e)
        {
            newGate = new InputSource(0, 0);
        }

        private void toolStripButtonOutputLamp_Click(object sender, EventArgs e)
        {
            newGate = new OutputLamp(0, 0);
        }

        private void toolStripButtonCopy_Click(object sender, EventArgs e)
        {
            if (current != null)
            {
                
                newGate = current.Clone();// Clone currently selected gate and assign to newGate

                
                newGate.MoveTo(current.Left + 20, current.Top + 20);// Move it slightly so it’s not exactly on top
                Invalidate();
            }
        }

        private void toolStripButtonStartGroup_Click(object sender, EventArgs e)
        {
            newCompound = new Compound(0, 0);
        }

        private void toolStripButtonEndGroup_Click(object sender, EventArgs e)
        {
            if (newCompound != null)
            {
                newGate = newCompound; // ready to place
                newCompound = null;
                Invalidate();
            }
        }

        private void toolStripButtonOrGate_Click(object sender, EventArgs e)
        {
            newGate = new OrGate(0, 0);
        }

        private void toolStripButtonNot_Click(object sender, EventArgs e)
        {
            newGate = new NotGate(0, 0);
        }

        /// <summary>
        /// Adds the currently selected gate to the newCompound group.
        /// </summary>
        private void AddSelectedToCompound()
        {
            if (current != null && newCompound != null)
            {
                newCompound.AddGate(current);
                current.Selected = false;
                current = null;
                Invalidate(); // redraw
            }
        }
    }
}
