﻿using System.Drawing;
using Circuits.Properties;

namespace Circuits
{
    public class NotGate : Gate
    {
        public NotGate(int x, int y) : base(x, y)
        {
            // Load normal and selected images from Resources
            imgNormal = Resources.NotGate;
            imgSelected = Resources.NotGateAllRed; // make sure you have this in Resources

            // Single input on the left
            Pins.Add(new Pin(this, false, 0, 25));  // input
            // Single output on the right
            Pins.Add(new Pin(this, true, 50, 25));  // output
        }

        /// <summary>
        /// Evaluate the NOT of the input pin
        /// </summary>
        public override bool Evaluate()
        {
            var inputPin = Pins.Find(p => !p.IsOutput);
            bool inputValue = inputPin?.InputWire?.Value ?? false;

            bool outputValue = !inputValue;

            // Update output pin value
            var outputPin = Pins.Find(p => p.IsOutput);
            if (outputPin != null)
                outputPin.Value = outputValue;

            return outputValue;
        }

        public override void Draw(Graphics g)
        {
            // Draw the image / change colour
            g.DrawImage(Selected && imgSelected != null ? imgSelected : imgNormal, Left, Top, 50, 50);

            // Draw pins
            foreach (var p in Pins)
                p.Draw(g);
        }

        public override Gate Clone()
        {
            var copy = new NotGate(Left, Top);

            // Clone each pin
            copy.Pins.Clear();
            foreach (var pin in Pins)
            {
                copy.Pins.Add(new Pin(copy, pin.IsOutput, pin.OffsetX, pin.OffsetY));
            }

            return copy;
        }
    }

}
